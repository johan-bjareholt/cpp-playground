Otur i tärning
==============

Ett simpelt cli tärnings spel
