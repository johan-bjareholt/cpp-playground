#!/bin/bash
g++ --std=c++11 -o otur\ i\ tärning main.cpp
