#include <iostream>

#include "board.h"

std::string playernames[PLAYERAMOUNT];
bool 	boats[PLAYERAMOUNT][BOARDSIZE];
short 	shots[PLAYERAMOUNT][BOARDSIZE];
int 	shipsleft[PLAYERAMOUNT];

void generateShips(int shipamount){
	for (int playeri=0; playeri<2; playeri++){
		shipsleft[playeri]  = shipamount;
		// Add board
		for (int boatn=0; boatn<3; boatn++){
			int position = rand() % 15;
			// Check so there's not already a ship at that position
			while (boats[playeri][position])
				position = rand() % 15;
			boats[playeri][position] = true;
		}
	}
}

void pprintBoard(int playeri){
	for (int n=0; n<BOARDSIZE; n++){
		switch (shots[playeri][n]){
			case 0:
				std::cout << "-";
				break;
			case 1:
				std::cout << "0";
				break;
			case 2:
				std::cout << "X";
				break;
		}
	}
	std::cout << std::endl;
}

void shoot(int playeri, int position){
	if (boats[playeri][position]){
		shipsleft[playeri]--;
		boats[playeri][position] = false;
		shots[playeri][position] = 2;
		std::cout << "Skottet träffade!" << std::endl;
		pprintBoard(playeri);
	}
	else {
		shots[playeri][position] = 1;
		std::cout << "Skott missade!" << std::endl;
		pprintBoard(playeri);
	}
}