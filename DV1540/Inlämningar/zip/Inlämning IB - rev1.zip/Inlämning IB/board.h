#ifndef _BOARD_H
#define _BOARD_H

const int PLAYERAMOUNT = 2;

extern std::string playernames[PLAYERAMOUNT];

const int BOARDSIZE = 15;

extern bool 	boats[PLAYERAMOUNT][BOARDSIZE];
// 0 stands for untouched, 1 stands for missed, 2 stands for hit
extern short 	shots[PLAYERAMOUNT][BOARDSIZE];
extern int 	shipsleft[PLAYERAMOUNT];

void generateShips(int shipamount);
void pprintBoard(int playeri);
void shoot(int playeri, int position);

#endif