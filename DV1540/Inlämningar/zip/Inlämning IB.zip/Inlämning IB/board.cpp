#include <iostream>

#include "board.h"

Board::Board () {
	for (int n=0; n<BOARDSIZE; n++){
		this->boats[n] = false;
		this->shots[n] = false;
	}	
}

void Board::generateShips(int shipamount){
	this->shipamount = shipamount;
	this->shipsleft  = shipamount;
	// Add board
	for (int boatn=0; boatn<3; boatn++){
		int position = rand() % 15;
		// Check so there's not already a ship at that position
		while (boats[position])
			position = rand() % 15;
		boats[position] = true;
	}
}

void Board::pprintBoard(){
	for (int n=0; n<BOARDSIZE; n++){
		switch (shots[n]){
			case 0:
				std::cout << "-";
				break;
			case 1:
				std::cout << "0";
				break;
			case 2:
				std::cout << "X";
				break;
		}
	}
	std::cout << std::endl;
}

void Board::shoot(int position){
	if (boats[position]){
		shipsleft--;
		boats[position] = false;
		shots[position] = 2;
		std::cout << "Skottet träffade!" << std::endl;
		this->pprintBoard();
	}
	else {
		shots[position] = 1;
		std::cout << "Skott missade!" << std::endl;
		this->pprintBoard();
	}
}