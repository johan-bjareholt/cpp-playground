#ifndef _BOARD_H
#define _BOARD_H

const int BOARDSIZE = 15;

class Board {
	int shipamount;
	bool boats[BOARDSIZE];
	// 0 stands for untouched, 1 stands for missed, 2 stands for hit
	short shots[BOARDSIZE];
public:
	int shipsleft;

	Board();
	void generateShips(int);
	void pprintBoard();
	void shoot(int);
};

#endif