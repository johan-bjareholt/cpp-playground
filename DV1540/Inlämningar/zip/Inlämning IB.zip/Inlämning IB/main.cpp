#include <iostream>
#include <cstdlib>
#include <time.h>
#include <vector>

#include "board.h"
#include "player.h"

void clearScreen(){
	#ifdef _WIN32
	system("CLS")
	#else
	system("clear");
	#endif
}

void game(){
	clearScreen();

	// Ask for shipamount
	std::cout << "Hur många skepp ska varje spelare ha? ";
	int shipamount;
	std::cin >> shipamount;


	// Create players
	std::cin.clear();std::cin.ignore();
	std::string player1name, player2name;
	
	std::cout << "Vad är första spelarens namn? ";
	std::getline(std::cin, player1name);
	Player player1 = Player(player1name);
	
	std::cout << "Vad är den andra spelarens namn? ";
	std::getline(std::cin, player2name);
	Player player2 = Player(player2name);


	// Generate ships
	player1.board.generateShips(shipamount);
	player2.board.generateShips(shipamount);

	Player* currentPlayer = &player1;
	Player* otherPlayer	  = &player2;

	// Shoot loop
	while (player1.board.shipsleft>0 && player2.board.shipsleft>0)
	{
		std::cout << std::endl << "Nu är det " << currentPlayer->name << "s tur" << std::endl;
		// Shoot
		std::cout << "Skjut: ";
		int shootposition;
		std::cin >> shootposition;
		// Must clear buffer, else it will loop forever if you input a character instead of a number
		std::cin.clear();std::cin.ignore();

		if (shootposition<15 && shootposition>=0)
		{
			otherPlayer->board.shoot(shootposition);

			// Change player
			if (currentPlayer == &player1){
				currentPlayer = &player2;
				otherPlayer = &player1;
			}
			else {
				currentPlayer = &player1;
				otherPlayer = &player2;
			}
		}
		else 
		{
			std::cout << "Felaktigt alternativ, måste välja ett nummber mellan 0 och 14" << std::endl;
		}
	}

	clearScreen();

	Player* winner;
	if (player1.board.shipsleft > 0)
		winner = &player1;
	else
		winner = &player2;

	std::cout << "Och vinnaren är..." << std::endl << std::endl;

	std::cout << winner->name << "!" << std::endl << std::endl << std::endl;

}

int main(){
	srand(time(NULL));

	bool running=true;
	int choice;
	while (running){
		std::cout 	<< "Välkommen till sänka skepp" << std::endl
					<< "1. Starta spelet" << std::endl
					<< "2. Avsluta" << std::endl
					<< "Välj ett alternativ: ";
		std::cin >> choice;

		switch(choice){
			case 1:
				game();
				break;
			case 2:
				running=false;
				break;
			default:
				std::cout << "Ogiltigt alternativ" << std::endl;
		}
	}
	return 1;
}