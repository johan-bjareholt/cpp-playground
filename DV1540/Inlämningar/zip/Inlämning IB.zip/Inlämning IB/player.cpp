#include "board.h"
#include "player.h"


Player::Player(std::string name){
	this->name = name;
	this->board = Board();
}