#include <iostream>

#ifndef _PLAYER_H
#define _PLAYER_H

class Player{
public:
	std::string name;
	Player(std::string);
	Board board;
};

#endif