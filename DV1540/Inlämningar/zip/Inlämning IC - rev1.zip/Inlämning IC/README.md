Hitta den avlägsna punkten
==========================

Inlämningsuppgift IC i kursen DV1540 på Blekinge tekniska högskola

Kodad av Johan Bjäreholt
