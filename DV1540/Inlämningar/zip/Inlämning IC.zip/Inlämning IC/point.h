#ifndef POINT_H
#define POINT_H

#include <cmath>
#include <string>

class Point {
private:
	float x, y;
	int index;
	void setIndex();
public:
	Point();
	Point(float,float);
	int getIndex();
	static int nextindex;
	std::string info();
	// Coordinates management
	float getX();
	float getY();
	void setCoordinates(int,int);
	float distance(Point*);
	float distance(float,float);
};

#endif