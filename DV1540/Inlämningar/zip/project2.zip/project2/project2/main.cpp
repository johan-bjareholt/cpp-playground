#include <iostream>
#include <string>
#include <time.h>
#include <cstdio>

using namespace std;

int main (){
	setlocale(0,"swedish");

	

	return 0;
}

/*
Uppgift 23

int main (){
	setlocale(0,"swedish");

	int a, b;
	cin >> a;
	cout << "+";
	cin >> b;
	cout << "--------";
	cin.ignore();
	cin.get();
	cout << a+b << endl;

	return 0;
}


*/

/*
Uppfigt 20

int main (){
	setlocale(0,"swedish");

	int yi = 1;
	double yd = (double)(yi);
	yi = (int)(yd);

	return 0;
}

*/

/*
Skriver alla ascii symboler

int main (){
	setlocale(0,"swedish");
	char character;
	for (int n=0; n<256; n++){
		character = n;
		cout << character;
	}
	return 0;
}

*/

/*
Uppgift 15

int main (){
	setlocale(0,"swedish");

	FILE * myfile;

	myfile = fopen("testfile.txt", "w");

	fprintf(myfile, "hejhej\ngoddag!");

	fclose(myfile);

	return 0;
}

*/


/*
Uppgift 17

int main (){
	setlocale(0,"swedish");

	srand (time(NULL));

	string name1, name2;
	cout << "Spelare 1: ";
	getline(cin, name1);
	cout << "Spelare 2: ";
	getline(cin, name2);

	int score1, score2;
	
	score1 = rand() % 6+1;
	score1 += rand() % 6+1;

	score2 = rand() % 6+1;
	score2 += rand() % 6+1;

	cout << name1 << " fick " << score1 << " po�ng" << endl;
	cout << name2 << " fick " << score2 << " po�ng" << endl;
	if (score1 > score2){
		cout << "Spelare 1 vann!" << endl;
	}
	else if ( score2 > score1){
		cout << "Spelare 2 vann!" << endl;
	}
	else {
		cout << "Ni b�da �r sopor! hah!";
	}

	return 0;
}

*/

/*
Uppgift 16

int kg;
cin >> kg;
double lb = kg*2.2;
cout << kg << "kg is " << lb << " pounds" << endl;
*/

/*
Uppgift 15

int main (){
	setlocale(0,"swedish");

	// Arrival input
	int arrivalDay, arrivalMonth, arrivalYear;
	cout << "Ankomst" << endl;
	cout << "Dag: ";
	cin >> arrivalDay;
	cout << "M�nad: ";
	cin >> arrivalMonth;
	cout << "�r: ";
	cin >> arrivalYear;

	cout << endl;

	// Departure input
	int departureDay, departureMonth, departureYear;
	cout << "Avresa" << endl;
	cout << "Dag: ";
	cin >> departureDay;
	cout << "M�nad: ";
	cin >> departureMonth;
	cout << "�r: ";
	cin >> departureYear;


	// Error handling
	if (arrivalYear > departureYear){
		cout << "Error: Arrival year later than departure year" << endl;
		return -1;
	}
	else if (arrivalYear == departureYear){
		if (arrivalMonth > departureMonth){
			cout << "Error: Arrival month earlier than departure month" << endl;
			return -1;
		}
		else if (arrivalMonth == departureMonth){
			if (arrivalDay > departureDay){
				cout << "Error: Arrival day later than departure day" << endl;
				return -1;
			}
		}
	}

	// Result
	int totalDays = 0;
	totalDays += (departureYear-arrivalYear)*365;
	totalDays += (departureMonth-arrivalMonth)*31;
	totalDays += departureDay-arrivalDay;

	cout << "The stay will be " << totalDays << " long" << endl;

	return 0;
}

*/

/*
Uppgift 14

int nyLon = 15000*1.075
int retroiaktivlon = 15000*0.075

*/

/*
Uppgift 13

n=5
k=3
n*2+k = (5*2)+3 = 13

n*(2+k) = 5*(5) = 25

*/

/*
Uppgift 12

i=i+1;
i+=1;
i++;

*/

/*
Uppgift 11

n=10
k=2*n=20
m=100
m+= k+n
m+k+n=100+20+10=130

130

*/

/*
Uppgift 10

Att det �kar med v�rdet 1

*/

/*
Uppgift 8

int x, y;

3*x
3*x+y
(x+y)/7
(3*x+y)/(z+2)

*/

/*
Uppgift 7

int main (){
	setlocale(0,"swedish");

	int pengar;
	
	cout << "Hur mycket skulle du vilja v�xla?";
	cin >> pengar;

	cout << "Detta skulle motsvara: " <<endl;

	cout << pengar/100 << "st hundra kronors sedlar" << endl;
	pengar %= 100;
	cout << pengar/50 << "st femtio kronors sedlar" << endl;
	pengar %= 50;
	cout << pengar/20 << "st tjugo kronors sedlar" << endl;
	pengar %= 20;
	cout << pengar/5 << "st femkronor" << endl;
	pengar %= 5;
	cout << pengar << "st enkronor" << endl;

	return 0;
}


*/

/*
Uppgift 6


int main (){
	setlocale(0,"swedish");

	int sum;
	double ranta;
	cout << "Ange en summa: ";
	cin >> sum;
	cout << "Ange en r�ntesats i procent: " << endl;
	cin >> ranta;

	cout << ranta << "% r�nta p� " << sum << " �r " << ranta*sum << endl;


	return 0;
}
*/

/*
Gammal kod

class Person {
public:
	string name, age, city;
	Person(string name, string age, string city){
		this->name = name;
		this->age = age;
		this->city = city;
	}
};
int main (){
	string name, age, city;
	cout << "Vad heter du? ";
	getline(cin, name);
	cout << "Hall� " << name << "!" << endl;
	cout << "Var bor du? ";
	getline(cin, city);
	cout << endl;
	cout << "Hur gammal �r du? ";
	getline(cin,age);
	Person you = Person(name, age, city);
	return 0;
}
*/

/*
Gammal kod

	int myNumber[2];
	myNumber[0];
	myNumber[1];

	int sum = 0;

	for (int n=0; n<2; n++){
		cout << endl << "Skriv in ett heltal: "; 
		cin >> myNumber[n];
	}
	
	for(int n=0; n<2; n++){
		cout << "Nummer" << n << ": " << myNumber[n] << endl;
		sum += myNumber[n];
	}
	cout << "Summa: " << sum << endl;


	double myDouble = 2.0;
	cout << "Float: " << myDouble << endl;

*/